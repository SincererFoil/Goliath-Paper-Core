package ch.mcserver.goliathPaperCore.module.anticheat;


import ch.mcserver.goliathPaperCore.GoliathPaperCore;
import ch.mcserver.goliathPaperCore.module.anticheat.data.AnticheatStateService;

import ch.mcserver.goliathPaperCore.module.anticheat.data.player.PlayerDataManager;
import ch.mcserver.goliathPaperCore.module.anticheat.data.player.playerdata.PlayerData;
import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketListenerPriority;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

import java.util.UUID;
import java.util.logging.Level;

public class AnticheatListener extends PacketListenerAbstract implements Listener {

    private final PlayerDataManager playerDataManager;

    private final AnticheatStateService stateService;

    public AnticheatListener(Plugin plugin, PlayerDataManager playerDataManager, AnticheatStateService stateService) {
        super(PacketListenerPriority.NORMAL);

        this.playerDataManager = playerDataManager;
        this.stateService = stateService;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();

        PlayerData data = playerDataManager.create(player.getUniqueId(), player.getName());

        stateService.load(data);
    }

    @EventHandler
    public void onPlayerDisconnect(PlayerQuitEvent event) {
        Player player = event.getPlayer();

        PlayerData data = playerDataManager.get(player.getUniqueId());

        if (data == null) {
            GoliathPaperCore.getInstance().getLogger().log(Level.WARNING, "Anticheat couldn't save the player data for " + event.getPlayer().getName());
            return;
        }

        stateService.save(data);

        playerDataManager.remove(player.getUniqueId());
    }


}