package ch.mcserver.goliathPaperCore;

import ch.mcserver.goliathPaperCore.common.database.mongodb.ChatLogRepository;
import ch.mcserver.goliathPaperCore.common.database.mongodb.HistoryRepository;
import ch.mcserver.goliathPaperCore.common.database.mongodb.MongoDBManager;
import ch.mcserver.goliathPaperCore.common.database.mysql.MySQLManager;
import ch.mcserver.goliathPaperCore.common.database.mysql.PlayerRepository;
import ch.mcserver.goliathPaperCore.common.database.redis.RedisManager;
import ch.mcserver.goliathPaperCore.module.anticheat.data.AnticheatStateService;
import ch.mcserver.goliathPaperCore.module.history.snapshot.PlayerInventorySnapshotRepository;
import ch.mcserver.goliathPaperCore.module.inventory.PlayerInventoryRepository;
import org.bukkit.plugin.java.JavaPlugin;
import org.spongepowered.configurate.ConfigurationNode;
import org.spongepowered.configurate.yaml.YamlConfigurationLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class GoliathPaperCore extends JavaPlugin {

    public static ConfigurationNode config;
    public static PlayerRepository playerRepository;
    public static HistoryRepository historyRepository;
    public static ChatLogRepository chatLogRepository;
    public static PlayerInventorySnapshotRepository playerInventorySnapshotRepository;
    public static PlayerInventoryRepository playerInventoryRepository;

    private static GoliathPaperCore instance;

    private Logger logger;

    private RedisManager redisManager;
    private MongoDBManager mongoManager;
    private MySQLManager mySQLManager;
    private PluginRegister pluginRegister;
    public static String serverName;

    @Override
    public void onEnable() {
        instance = this;
        logger = getLogger();

        loadConfig();

        mongoManager = new MongoDBManager();
        mongoManager.connect();

        mySQLManager = new MySQLManager();
        mySQLManager.connect();

        redisManager = new RedisManager();
        redisManager.connect();

        playerRepository = new PlayerRepository(mySQLManager);

        pluginRegister = new PluginRegister(this, mongoManager, mySQLManager);
        pluginRegister.registerAll();

        logger.info("Plugin Enabled!");
    }

    @Override
    public void onDisable() {

        pluginRegister.onDisable();

        if (pluginRegister != null && pluginRegister.getShutdownService() != null) {
            pluginRegister.getShutdownService().shutdown();
        }

        if (mongoManager != null) {
            mongoManager.disconnect();
        }

        if (mySQLManager != null) {
            mySQLManager.disconnect();
        }

        if (redisManager != null) {
            redisManager.close();
        }


        logger.info("Plugin Disabled!");
    }

    public static GoliathPaperCore getInstance() {
        return instance;
    }

    public static PlayerRepository getPlayerRepository() {
        return playerRepository;
    }

    public static PlayerInventorySnapshotRepository getPlayerInventorySnapshotRepository() {
        return playerInventorySnapshotRepository;
    }

    public RedisManager getRedisManager() {
        return redisManager;
    }

    public static HistoryRepository getHistoryRepository() {
        return historyRepository;
    }

    public static ChatLogRepository getChatLogRepository() {
        return chatLogRepository;
    }

    public static PlayerInventoryRepository getPlayerInventoryRepository() {
        return playerInventoryRepository;
    }

    private void loadConfig() {
        try {
            Path dataDirectory = getDataFolder().toPath();
            Files.createDirectories(dataDirectory);

            Path configPath = dataDirectory.resolve("config.yml");
            YamlConfigurationLoader loader = YamlConfigurationLoader.builder()
                    .path(configPath)
                    .build();

            if (!Files.exists(configPath)) {
                config = loader.createNode();

                config.node("mongodb", "uri").set("YOUR_MONGO_CONNECTION_STRING");
                config.node("mysql", "host").set("127.0.0.1");
                config.node("mysql", "port").set(3306);
                config.node("mysql", "database").set("goliath");
                config.node("mysql", "username").set("goliath");
                config.node("mysql", "password").set("YOUR_PASSWORD");
                config.node("redis", "ipaddress").set("127.0.0.1");
                config.node("redis", "port").set("6379");
                config.node("redis", "password").set("YOUR_PASSWORD");

                config.node("server", "isSpawn").set(false);
                config.node("server", "name").set("goliath-unknown");

                loader.save(config);
                logger.info("Config file has been created");
            }

            config = loader.load();
            serverName = config.node("server", "name").getString("goliath-unknown");

            if ("goliath-unknown".equals(serverName)) {
                logger.warning("The Servername in the config.yml is not set or couldn't load");
            }

        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to load config.yml!", e);
        }
    }
}
