package ch.mcserver.goliathPaperCore;

import ch.mcserver.goliathPaperCore.common.database.mongodb.ChatLogRepository;
import ch.mcserver.goliathPaperCore.common.database.mongodb.HistoryRepository;
import ch.mcserver.goliathPaperCore.common.database.mongodb.MongoDBManager;
import ch.mcserver.goliathPaperCore.common.database.mysql.*;
import ch.mcserver.goliathPaperCore.common.pluginmessage.CommandUpdateMessenger;
import ch.mcserver.goliathPaperCore.common.pluginmessage.CreativeMessenger;
import ch.mcserver.goliathPaperCore.common.pluginmessage.GmspMessenger;
import ch.mcserver.goliathPaperCore.common.pluginmessage.GoliathTeleportMessenger;
import ch.mcserver.goliathPaperCore.common.pluginmessage.HistorySnapshotMessenger;
import ch.mcserver.goliathPaperCore.common.pluginmessage.LocationMessenger;
import ch.mcserver.goliathPaperCore.common.service.CommandErrorService;
import ch.mcserver.goliathPaperCore.common.service.ShutdownService;
import ch.mcserver.goliathPaperCore.common.service.SpawnerService;
import ch.mcserver.goliathPaperCore.module.anticheat.AnticheatListener;
import ch.mcserver.goliathPaperCore.module.anticheat.data.AnticheatStateService;
import ch.mcserver.goliathPaperCore.module.anticheat.data.player.PlayerDataManager;
import ch.mcserver.goliathPaperCore.module.anticheat.data.player.playerdata.PlayerData;
import ch.mcserver.goliathPaperCore.module.anticheat.flag.FlagManager;
import ch.mcserver.goliathPaperCore.module.chat.GoliathChat;
import ch.mcserver.goliathPaperCore.module.enderchest.EnderchestListener;
import ch.mcserver.goliathPaperCore.module.enderchest.EnderchestService;
import ch.mcserver.goliathPaperCore.module.enderchest.PlayerEnderchestRepository;
import ch.mcserver.goliathPaperCore.module.enderchest.command.GoliathEnderchestCommand;
import ch.mcserver.goliathPaperCore.module.enderchest.command.GoliathEnderchestViewListener;
import ch.mcserver.goliathPaperCore.module.enderchest.command.ShowGoliathEnderchest;
import ch.mcserver.goliathPaperCore.module.history.gui.HistoryGuiListener;
import ch.mcserver.goliathPaperCore.module.history.gui.ShowHistory;
import ch.mcserver.goliathPaperCore.module.history.gui.inventory.HistoryInventoryGuiListener;
import ch.mcserver.goliathPaperCore.module.history.gui.specific.SpecificHistoryGuiListener;
import ch.mcserver.goliathPaperCore.module.history.snapshot.PlayerInventorySnapshotRepository;
import ch.mcserver.goliathPaperCore.module.inventory.InventoryListener;
import ch.mcserver.goliathPaperCore.module.inventory.PlayerInventoryRepository;
import ch.mcserver.goliathPaperCore.module.spawn.DoubleJumpBoostListener;
import ch.mcserver.goliathPaperCore.module.spawn.SpawnListener;
import ch.mcserver.goliathPaperCore.module.spawnstash.SpawnStashCommand;
import ch.mcserver.goliathPaperCore.module.spawnstash.SpawnStashTabCompleter;
import com.github.retrooper.packetevents.PacketEvents;
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class PluginRegister {

    private final GoliathPaperCore plugin;
    private final MongoDBManager mongoManager;
    private final MySQLManager mySQLManager;

    private MongoCollection<Document> enderchestCollection;
    private PlayerEnderchestRepository enderchestRepository;
    private EnderchestService enderchestService;

    private MongoCollection<Document> inventoryCollection;
    private PlayerInventoryRepository playerInventoryRepository;

    private MongoCollection<Document> historyCollection;
    private MongoCollection<Document> chatLogCollection;
    private HistoryRepository historyRepository;
    private ChatLogRepository chatLogRepository;

    private MongoCollection<Document> historyPlayerInventoryCollection;
    private PlayerInventorySnapshotRepository playerInventorySnapshotRepository;

    private PlayerLocationRepository playerLocationRepository;
    private PlayerLocationManager playerLocationManager;

    private GoliathChat goliathChat;

    private PlayerDataManager playerDataManager;
    private AnticheatRepository anticheatRepository;
    private AnticheatStateService anticheatStateService;
    private AnticheatListener anticheatListener;

    private ShutdownService shutdownService;

    private FlagManager flagManager;

    public PluginRegister(GoliathPaperCore plugin, MongoDBManager mongoManager, MySQLManager mySQLManager) {
        this.plugin = plugin;
        this.mongoManager = mongoManager;
        this.mySQLManager = mySQLManager;
    }

    public void registerAll() {
        registerManagers();
        registerCommands();
        registerListeners();
        registerPluginMessaging();
        registerSchedulers();
    }

    public ShutdownService getShutdownService() {
        return shutdownService;
    }


    private void registerManagers() {
        this.inventoryCollection = this.mongoManager.getMongoCollection("player_inventory");
        this.playerInventoryRepository = new PlayerInventoryRepository(inventoryCollection);

        this.chatLogCollection = this.mongoManager.getMongoCollection("chat_log");
        this.chatLogRepository = new ChatLogRepository(chatLogCollection);
        GoliathPaperCore.chatLogRepository = this.chatLogRepository;

        this.enderchestCollection = this.mongoManager.getMongoCollection("player_enderchest");
        this.enderchestRepository = new PlayerEnderchestRepository(enderchestCollection);
        this.enderchestService = new EnderchestService(enderchestRepository);

        this.historyCollection = this.mongoManager.getMongoCollection("history_events");
        this.historyRepository = new HistoryRepository(historyCollection);
        GoliathPaperCore.historyRepository = this.historyRepository;


        this.historyPlayerInventoryCollection = this.mongoManager.getMongoCollection("history_player_inventory_snapshot");
        this.playerInventorySnapshotRepository = new PlayerInventorySnapshotRepository(historyPlayerInventoryCollection);
        GoliathPaperCore.playerInventorySnapshotRepository = this.playerInventorySnapshotRepository;

        this.playerLocationRepository = new PlayerLocationRepository(mySQLManager);
        this.goliathChat = new GoliathChat(plugin);
        String serverName = GoliathPaperCore.config
                .node("server", "name")
                .getString("unknown");

        this.playerLocationManager = new PlayerLocationManager(
                plugin,
                playerLocationRepository,
                serverName
        );

        this.shutdownService = new ShutdownService(
                this.plugin.getLogger(),
                this.mongoManager,
                this.enderchestService,
                this.playerInventoryRepository
        );

        this.flagManager = new FlagManager(
                plugin,
                plugin.getRedisManager()
        );

        this.playerDataManager = new PlayerDataManager(flagManager);

        this.anticheatRepository = new AnticheatRepository(mySQLManager);

        this.anticheatStateService = new AnticheatStateService(
                plugin,
                anticheatRepository,
                playerDataManager
        );

        this.anticheatListener = new AnticheatListener(
                plugin,
                playerDataManager,
                anticheatStateService
        );
    }

    public void onDisable() {
        anticheatStateService.shutdown();
    }


    private void registerCommands() {
        plugin.getCommand("spawnstash").setExecutor(new SpawnStashCommand());
        plugin.getCommand("spawnstash").setTabCompleter(new SpawnStashTabCompleter());

        ShowGoliathEnderchest showGoliathEnderchest = new ShowGoliathEnderchest(enderchestRepository);
        plugin.getCommand("echest").setExecutor(new GoliathEnderchestCommand(showGoliathEnderchest));
        plugin.getCommand("history").setExecutor(new ShowHistory());
    }

    private void registerListeners() {
        boolean isSpawn = GoliathPaperCore.config
                .node("server", "isSpawn")
                .getBoolean(false);

        if (isSpawn) {
            plugin.getServer().getPluginManager()
                    .registerEvents(new SpawnListener(), plugin);

            plugin.getServer().getPluginManager()
                    .registerEvents(new DoubleJumpBoostListener(plugin), plugin);
        }

        plugin.getServer().getPluginManager()
                .registerEvents(goliathChat, plugin);

        goliathChat.startChatSubscriber();

        plugin.getServer().getPluginManager()
                .registerEvents(new CommandErrorService(), plugin);

        plugin.getServer().getPluginManager()
                .registerEvents(new EnderchestListener(enderchestService, enderchestRepository), plugin);

        plugin.getServer().getPluginManager()
                .registerEvents(new GoliathEnderchestViewListener(enderchestRepository), plugin);

        plugin.getServer().getPluginManager()
                .registerEvents(new InventoryListener(playerInventoryRepository), plugin);

        plugin.getServer().getPluginManager()
                .registerEvents(new SpawnerService(), plugin);

        plugin.getServer().getPluginManager()
                .registerEvents(new HistoryGuiListener(), plugin);

        plugin.getServer().getPluginManager()
                .registerEvents(new PlayerObjectManager(), plugin);

        plugin.getServer().getPluginManager()
                .registerEvents(new SpecificHistoryGuiListener(), plugin);

        plugin.getServer().getPluginManager()
                .registerEvents(new HistoryInventoryGuiListener(), plugin);

        plugin.getServer().getPluginManager()
                .registerEvents(anticheatListener, plugin);



        PacketEvents.getAPI().getEventManager()
                .registerListener(anticheatListener);


    }

    private void registerPluginMessaging() {
        plugin.getServer().getMessenger().registerIncomingPluginChannel(
                plugin,
                "goliath:gtp",
                new GoliathTeleportMessenger(playerLocationRepository)
        );

        plugin.getServer().getMessenger().registerIncomingPluginChannel(
                plugin,
                "goliath:gmsp",
                new GmspMessenger()
        );

        plugin.getServer().getMessenger().registerIncomingPluginChannel(
                plugin,
                "goliath:updatecommands",
                new CommandUpdateMessenger()
        );

        plugin.getServer().getMessenger().registerIncomingPluginChannel(
                plugin,
                "goliath:history",
                new HistorySnapshotMessenger()
        );

        new LocationMessenger(plugin);

        CreativeMessenger creativeMessenger = new CreativeMessenger(plugin);
        plugin.getServer().getPluginManager().registerEvents(creativeMessenger, plugin);
    }

    private void registerSchedulers() {
        Bukkit.getScheduler().runTaskTimerAsynchronously(
                plugin,
                () -> {
                    if (playerInventoryRepository == null) {
                        return;
                    }

                    for (Player player : Bukkit.getOnlinePlayers()) {
                        playerInventoryRepository.saveInventory(player.getUniqueId());
                    }
                },
                20L * 60 * 5,
                20L * 60 * 5
        );


        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            anticheatStateService.saveAll();
        }, 20L * 60, 20L * 60
        );
    }
}